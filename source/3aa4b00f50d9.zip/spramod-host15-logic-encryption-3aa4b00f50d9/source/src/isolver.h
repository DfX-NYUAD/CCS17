#ifndef _ISOLVER_H_DEFINED_
#define _ISOLVER_H_DEFINED_

struct isolver
{
};

#endif
