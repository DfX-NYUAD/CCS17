#ifndef _SLE_H_DEFINED_
#define _SLE_H_DEFINED_

int sle_main(int argc, char* argv[]);
int sle_usage(const char* progname);

#endif
