#ifndef _RANDOMINS_H_DEFINED_
#define _RANDOMINS_H_DEFINED_

#include "ckt.h"

namespace ckt_n {
    void random_insert(ckt_t& ckt, int numKeys);
}

#endif
